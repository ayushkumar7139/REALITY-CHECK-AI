import streamlit as st


def inject_custom_css(dark_mode: bool = True, *args, **kwargs):
    if "dark_mode" in kwargs:
        dark_mode = kwargs["dark_mode"]
    elif args:
        dark_mode = bool(args[0])

    if dark_mode:
        st.markdown("""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Chakra+Petch:wght@500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap');
        
        /* UNIVERSAL TEXT OVERRIDE: NO BLACK TEXT ALLOWED */
        .stApp, 
        .stApp p, 
        .stApp span, 
        .stApp div, 
        .stApp label, 
        .stApp li, 
        .stApp strong,
        .stApp b,
        [data-testid="stMarkdownContainer"] *,
        [class*="st-emotion-cache"] {
            color: #F8FAFC !important;
        }

        /* Pure white for headings and key values */
        h1, h2, h3, h4, h5, h6,
        .stApp h1, .stApp h2, .stApp h3, .stApp h4,
        [data-testid="stMarkdownContainer"] h1,
        [data-testid="stMarkdownContainer"] h2,
        [data-testid="stMarkdownContainer"] h3,
        [data-testid="stMarkdownContainer"] h4,
        [data-testid="stMarkdownContainer"] strong,
        .brand-title, .panel-title, .kpi-value {
            color: #FFFFFF !important;
        }

        /* Background Aurora styling */
        .stApp {
            background-color: #07090E !important;
            background: 
                radial-gradient(ellipse 80% 50% at 50% -10%, rgba(236, 72, 153, 0.16), transparent),
                radial-gradient(ellipse 60% 40% at 85% 15%, rgba(139, 92, 246, 0.14), transparent),
                radial-gradient(ellipse 50% 30% at 15% 30%, rgba(6, 182, 212, 0.12), transparent),
                #07090E !important;
            background-attachment: fixed !important;
        }

        /* Sidebar Glassmorphic */
        section[data-testid="stSidebar"] {
            background-color: rgba(11, 15, 25, 0.95) !important;
            border-right: 1px solid rgba(255, 255, 255, 0.12) !important;
            backdrop-filter: blur(24px) !important;
        }
        section[data-testid="stSidebar"] * {
            color: #F8FAFC !important;
        }

        /* Secondary & muted captions */
        .stCaption, small, 
        [data-testid="stCaptionContainer"],
        [data-testid="stCaptionContainer"] *,
        .kpi-title, .kpi-subtext, .panel-subtitle {
            color: #94A3B8 !important;
        }

        /* Top Brand Navigation Bar */
        .brand-top-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.9rem 1.4rem;
            background: rgba(18, 24, 38, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.14);
            backdrop-filter: blur(20px);
            border-radius: 16px;
            margin-bottom: 1.5rem;
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.45);
        }
        .brand-logo-group {
            display: flex;
            align-items: center;
            gap: 0.95rem;
        }
        .brand-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #EC4899 0%, #8B5CF6 50%, #06B6D4 100%);
            color: #FFFFFF !important;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 1.15rem;
            box-shadow: 0 0 20px rgba(139, 92, 246, 0.45);
        }
        .brand-title {
            font-size: 1.25rem;
            font-weight: 800;
            letter-spacing: -0.02em;
            color: #FFFFFF !important;
            margin: 0;
            line-height: 1.2;
        }
        .brand-subtitle {
            font-size: 0.78rem;
            font-weight: 500;
            color: #94A3B8 !important;
            margin: 0;
            letter-spacing: 0.03em;
        }
        .brand-badge {
            font-size: 0.75rem;
            font-weight: 600;
            background: rgba(255, 255, 255, 0.08);
            color: #E2E8F0 !important;
            border: 1px solid rgba(255, 255, 255, 0.15);
            padding: 0.35rem 0.8rem;
            border-radius: 9999px;
            display: inline-flex;
            align-items: center;
            gap: 0.45rem;
        }
        .brand-badge * {
            color: #E2E8F0 !important;
        }
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #10B981;
            box-shadow: 0 0 10px #10B981;
        }

        /* KPI Cards */
        .kpi-card {
            background: rgba(18, 24, 38, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(20px);
            border-radius: 18px;
            padding: 1.25rem 1.35rem;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
        }
        .kpi-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, rgba(236, 72, 153, 0.7), rgba(6, 182, 212, 0.7), transparent);
        }
        .kpi-title {
            font-size: 0.76rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.08em;
            color: #94A3B8 !important;
            margin-bottom: 0.35rem;
        }
        .kpi-value {
            font-family: 'Chakra Petch', 'JetBrains Mono', monospace !important;
            font-size: 2.3rem;
            font-weight: 700;
            color: #FFFFFF !important;
            line-height: 1.1;
            margin-bottom: 0.25rem;
            letter-spacing: -0.02em;
        }
        .kpi-subtext {
            font-size: 0.78rem;
            color: #94A3B8 !important;
        }

        /* Panel Card */
        .panel-card {
            background: rgba(18, 24, 38, 0.82);
            border: 1px solid rgba(255, 255, 255, 0.12);
            backdrop-filter: blur(20px);
            border-radius: 18px;
            padding: 1.4rem 1.6rem;
            margin-bottom: 1.4rem;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);
        }
        .panel-card * {
            color: #F8FAFC !important;
        }
        .panel-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            padding-bottom: 0.85rem;
            margin-bottom: 1.15rem;
        }
        .panel-title {
            font-size: 1.15rem;
            font-weight: 700;
            color: #FFFFFF !important;
            margin: 0;
        }
        .panel-subtitle {
            font-size: 0.82rem;
            color: #94A3B8 !important;
            margin-top: 0.2rem;
        }

        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 0.28rem 0.8rem;
            border-radius: 9999px;
            font-size: 0.76rem;
            font-weight: 700;
        }
        .badge-open {
            background: rgba(59, 130, 246, 0.25) !important;
            color: #BFDBFE !important;
            border: 1px solid rgba(59, 130, 246, 0.5) !important;
        }
        .badge-investigating {
            background: rgba(245, 158, 11, 0.25) !important;
            color: #FDE68A !important;
            border: 1px solid rgba(245, 158, 11, 0.5) !important;
        }
        .badge-action {
            background: rgba(239, 68, 68, 0.25) !important;
            color: #FECACA !important;
            border: 1px solid rgba(239, 68, 68, 0.5) !important;
        }
        .badge-resolved {
            background: rgba(16, 185, 129, 0.25) !important;
            color: #A7F3D0 !important;
            border: 1px solid rgba(16, 185, 129, 0.5) !important;
        }
        .badge-reopened {
            background: rgba(168, 85, 247, 0.25) !important;
            color: #E9D5FF !important;
            border: 1px solid rgba(168, 85, 247, 0.5) !important;
        }

        .priority-immediate {
            background: linear-gradient(135deg, #DC2626 0%, #991B1B 100%) !important;
            color: #FFFFFF !important;
            padding: 0.28rem 0.8rem;
            border-radius: 9999px;
            font-size: 0.76rem;
            font-weight: 700;
            box-shadow: 0 0 14px rgba(220, 38, 38, 0.6);
        }
        .priority-high {
            background: rgba(249, 115, 22, 0.25) !important;
            color: #FED7AA !important;
            border: 1px solid rgba(249, 115, 22, 0.5) !important;
            padding: 0.28rem 0.8rem;
            border-radius: 9999px;
            font-size: 0.76rem;
            font-weight: 700;
        }
        .priority-moderate {
            background: rgba(234, 179, 8, 0.25) !important;
            color: #FEF08A !important;
            border: 1px solid rgba(234, 179, 8, 0.5) !important;
            padding: 0.28rem 0.8rem;
            border-radius: 9999px;
            font-size: 0.76rem;
            font-weight: 700;
        }
        .priority-low {
            background: rgba(14, 165, 233, 0.25) !important;
            color: #BAE6FD !important;
            border: 1px solid rgba(14, 165, 233, 0.5) !important;
            padding: 0.28rem 0.8rem;
            border-radius: 9999px;
            font-size: 0.76rem;
            font-weight: 700;
        }

        /* Inputs, Textareas, Selectboxes */
        input, textarea, select,
        div[data-testid="stTextInput"] input, 
        div[data-testid="stTextArea"] textarea, 
        div[data-testid="stSelectbox"] select,
        div[data-baseweb="select"] div,
        div[data-baseweb="input"] input {
            background-color: #111622 !important;
            color: #FFFFFF !important;
            border: 1px solid rgba(255, 255, 255, 0.16) !important;
            border-radius: 12px !important;
        }
        div[data-testid="stTextInput"] label, 
        div[data-testid="stTextArea"] label,
        div[data-testid="stSelectbox"] label,
        div[data-testid="stRadio"] label,
        div[data-testid="stCheckbox"] label {
            color: #FFFFFF !important;
            font-weight: 600 !important;
        }

        /* Primary action button */
        .stButton>button[kind="primary"] {
            background: linear-gradient(135deg, #EC4899 0%, #8B5CF6 50%, #06B6D4 100%) !important;
            border: none !important;
            color: #FFFFFF !important;
            box-shadow: 0 4px 20px rgba(139, 92, 246, 0.45) !important;
        }
        .stButton>button {
            background: rgba(255, 255, 255, 0.08) !important;
            color: #FFFFFF !important;
            border: 1px solid rgba(255, 255, 255, 0.15) !important;
            border-radius: 12px !important;
        }
        </style>
        """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <style>
        html, body, .stApp {
            background-color: #F8FAFC !important;
            color: #0F172A !important;
        }
        .brand-top-bar {
            background: #FFFFFF;
            border: 1px solid #E2E8F0;
            border-radius: 16px;
            padding: 0.9rem 1.4rem;
        }
        .brand-title { color: #0F172A !important; }
        .panel-card, .kpi-card { background: #FFFFFF; border: 1px solid #E2E8F0; }
        </style>
        """, unsafe_allow_html=True)


def render_brand_header(active_module: str = "Overview", active_case_id: str = ""):
    st.markdown(f"""
    <div class="brand-top-bar">
        <div class="brand-logo-group">
            <div class="brand-icon">RC</div>
            <div>
                <h1 class="brand-title">REALITY CHECK AI <span style="font-size:0.75rem; font-weight:700; color:#EC4899; background:rgba(236,72,153,0.18); border:1px solid rgba(236,72,153,0.35); padding:2px 10px; border-radius:9999px; margin-left:8px;">AURORA 2.0</span></h1>
                <p class="brand-subtitle">Detect What People Miss · Real-World Visual Safety & Asset Intelligence</p>
            </div>
        </div>
        <div style="display: flex; align-items: center; gap: 0.85rem;">
            {f'<div class="brand-badge"><span style="color:#94A3B8;">Active Case:</span> <strong style="color:#FFFFFF;">{active_case_id}</strong></div>' if active_case_id else ''}
            <div class="brand-badge">
                <span class="status-dot"></span>
                <span style="color:#FFFFFF;">Gemma 4 Multimodal Vision</span>
            </div>
            <button onclick="if (window.parent && window.parent._rcToggleChat) {{ window.parent._rcToggleChat(); }} else if (window._rcToggleChat) {{ window._rcToggleChat(); }} else {{ const t = (window.parent ? window.parent.document : document).getElementById('rc-voice-trigger'); if(t) t.click(); }}" style="background: linear-gradient(135deg, #EC4899 0%, #8B5CF6 100%); color: white; border: none; border-radius: 9999px; padding: 6px 14px; font-size: 0.82rem; font-weight: 600; cursor: pointer; display: flex; align-items: center; gap: 6px; box-shadow: 0 0 15px rgba(236, 72, 153, 0.4); transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/></svg>
                AI Voice Assistant
            </button>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_kpi_card(title: str, value: str | int, subtext: str = "", trend_color: str = "#94A3B8"):
    st.markdown(f"""
    <div class="kpi-card">
        <div class="kpi-title">{title}</div>
        <div class="kpi-value">{value}</div>
        <div class="kpi-subtext" style="color: {trend_color};">{subtext}</div>
    </div>
    """, unsafe_allow_html=True)


def status_badge_html(status: str) -> str:
    status_map = {
        "Open": "badge-open",
        "Investigating": "badge-investigating",
        "Action Required": "badge-action",
        "Resolved": "badge-resolved",
        "Reopened": "badge-reopened"
    }
    css_class = status_map.get(status, "badge-open")
    return f'<span class="badge {css_class}">{status}</span>'


def priority_badge_html(priority: str) -> str:
    p = str(priority).strip()
    if "immediate" in p.lower():
        return '<span class="priority-immediate">⚡ Immediate Attention</span>'
    elif "high" in p.lower():
        return '<span class="priority-high">⚠️ High Priority</span>'
    elif "mod" in p.lower() or "med" in p.lower():
        return '<span class="priority-moderate">⚖️ Moderate Priority</span>'
    else:
        return '<span class="priority-low">ℹ️ Low Priority</span>'


def confidence_badge_html(conf: str) -> str:
    c = str(conf).strip().lower()
    if c == "high":
        return '<span style="background:rgba(16, 185, 129, 0.22); color:#A7F3D0 !important; border:1px solid rgba(16, 185, 129, 0.5); padding:3px 10px; border-radius:9999px; font-size:0.75rem; font-weight:700;">High Optical Confidence</span>'
    elif c == "medium":
        return '<span style="background:rgba(245, 158, 11, 0.22); color:#FEF08A !important; border:1px solid rgba(245, 158, 11, 0.5); padding:3px 10px; border-radius:9999px; font-size:0.75rem; font-weight:700;">Medium Optical Confidence</span>'
    else:
        return '<span style="background:rgba(148, 163, 184, 0.22); color:#F1F5F9 !important; border:1px solid rgba(148, 163, 184, 0.5); padding:3px 10px; border-radius:9999px; font-size:0.75rem; font-weight:700;">Low Optical Confidence</span>'
