import json
import logging
import os
import sys
import threading
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from typing import Optional, Dict, Any

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from google import genai
from google.genai import types

from modules.storage import get_all_cases, get_case_by_id
from modules.gemma_client import get_api_key, DEFAULT_GEMMA_MODEL

logger = logging.getLogger("voice_chat_server")
_SERVER_INSTANCE: Optional[ThreadingHTTPServer] = None
_SERVER_LOCK = threading.Lock()
_CURRENT_ACTIVE_CASE_ID: Optional[str] = None


def set_active_case_id(case_id: str) -> None:
    global _CURRENT_ACTIVE_CASE_ID
    _CURRENT_ACTIVE_CASE_ID = case_id


def get_active_case_id() -> Optional[str]:
    global _CURRENT_ACTIVE_CASE_ID
    if _CURRENT_ACTIVE_CASE_ID:
        return _CURRENT_ACTIVE_CASE_ID
    cases = get_all_cases()
    if cases:
        return cases[0]["id"]
    return None


def build_voice_assistant_prompt(user_query: str, case: Optional[Dict[str, Any]] = None) -> str:
    context_lines = []
    if case:
        findings = case.get("ai_findings", {})
        context_lines.append(f"CASE ID: {case.get('id', 'Unknown')}")
        context_lines.append(f"TITLE: {case.get('title', 'Untitled')}")
        context_lines.append(f"LOCATION: {case.get('location', 'Unspecified')}")
        context_lines.append(f"CATEGORY: {case.get('category', 'General')}")
        context_lines.append(f"STATUS: {case.get('status', 'Open')}")
        context_lines.append(f"SEVERITY/PRIORITY: {findings.get('suggested_priority', 'Moderate')}")
        context_lines.append(f"SUMMARY: {findings.get('summary', 'No summary recorded')}")
        
        obs = findings.get("visual_observations", [])
        if obs:
            context_lines.append(f"VERIFIED VISUAL EVIDENCE: {'; '.join(obs[:4])}")
            
        interp = findings.get("possible_interpretations", [])
        if interp:
            context_lines.append(f"INFERRED INTERPRETATIONS: {'; '.join(interp[:3])}")
            
        annotations = findings.get("annotations", [])
        if annotations:
            ann_strs = [f"{a.get('label', 'Defect')} at ({a.get('x',0):.0f}%, {a.get('y',0):.0f}%)" for a in annotations]
            context_lines.append(f"DEFECT COORDINATES: {'; '.join(ann_strs)}")
            
        checklist = findings.get("verification_checklist", [])
        if checklist:
            tasks = [f"[{'DONE' if t.get('completed') else 'PENDING'}] {t.get('task')}" for t in checklist[:4]]
            context_lines.append(f"INVESTIGATION CHECKLIST: {'; '.join(tasks)}")
    else:
        context_lines.append("No active inspection case selected. Provide general safety and inspection guidance.")

    context_str = "\n".join(context_lines)

    prompt = f"""You are REALITY CHECK AI Voice & Inspection Assistant, powered by Google Gemma.
You assist facility safety engineers and physical site inspectors.
Keep answers concise, direct, and conversational (under 120 words) so they are fast and sound natural when spoken.
Distinguish visual facts from inferences.

ACTIVE INSPECTION CONTEXT:
{context_str}

USER QUESTION / VOICE COMMAND:
"{user_query}"

Assistant Answer:"""
    return prompt


def generate_voice_assistant_response(user_query: str, case_id: Optional[str] = None) -> Dict[str, Any]:
    api_key = get_api_key()
    if not api_key:
        return {
            "reply": "Google AI API key is missing or not configured. Please add your GEMINI_API_KEY to `.streamlit/secrets.toml` or the Settings tab to enable AI responses.",
            "status": "error_no_key",
            "model": DEFAULT_GEMMA_MODEL
        }

    target_case_id = case_id or get_active_case_id()
    case = get_case_by_id(target_case_id) if target_case_id else None

    prompt = build_voice_assistant_prompt(user_query, case)

    try:
        client = genai.Client(api_key=api_key)
        config = types.GenerateContentConfig(
            max_output_tokens=300,
            temperature=0.1
        )
        response = client.models.generate_content(
            model=DEFAULT_GEMMA_MODEL,
            contents=prompt,
            config=config
        )
        
        reply_text = ""
        if hasattr(response, "text") and response.text:
            reply_text = response.text.strip()
        elif hasattr(response, "candidates") and response.candidates:
            c = response.candidates[0]
            if hasattr(c, "content") and hasattr(c.content, "parts") and c.content.parts:
                reply_text = "".join(part.text or "" for part in c.content.parts).strip()

        # Clean any raw thinking preamble from Gemma
        if reply_text:
            clean_lines = []
            for line in reply_text.split("\n"):
                s = line.strip()
                if s.startswith("*   Topic:") or s.startswith("*   Constraint") or s.startswith("*   Format:") or s.startswith("*   Role:"):
                    continue
                clean_lines.append(line)
            filtered = "\n".join(clean_lines).strip()
            if filtered:
                reply_text = filtered
                
        if not reply_text:
            reply_text = "I analyzed the context but could not form a response. Please rephrase your query."

        return {
            "reply": reply_text,
            "status": "ok",
            "case_id": target_case_id,
            "case_title": case.get("title", "") if case else "General",
            "model": DEFAULT_GEMMA_MODEL
        }
    except Exception as exc:
        err_msg = str(exc)
        if "API_KEY_INVALID" in err_msg or "400" in err_msg:
            friendly_err = "The provided Google AI API Key appears invalid or lacks permissions. Please verify your API key."
        elif "RESOURCE_EXHAUSTED" in err_msg or "429" in err_msg:
            friendly_err = "Rate limit reached. Please wait a few seconds before asking again."
        else:
            friendly_err = f"AI Service error: {err_msg}"
        return {
            "reply": friendly_err,
            "status": "error",
            "model": DEFAULT_GEMMA_MODEL
        }


class VoiceChatRequestHandler(BaseHTTPRequestHandler):
    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Access-Control-Max-Age", "86400")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == "/api/status":
            api_key = get_api_key()
            body = json.dumps({
                "status": "online",
                "model": DEFAULT_GEMMA_MODEL,
                "has_api_key": bool(api_key)
            }).encode("utf-8")
            self.send_response(200)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path.startswith("/api/active_case"):
            active_id = get_active_case_id()
            case = get_case_by_id(active_id) if active_id else None
            data = {
                "active_case_id": active_id,
                "title": case.get("title", "No Active Case") if case else "No Active Case",
                "severity": case.get("ai_findings", {}).get("suggested_priority", "Normal") if case else "Normal"
            }
            body = json.dumps(data).encode("utf-8")
            self.send_response(200)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self._send_cors_headers()
            self.end_headers()

    def do_POST(self):
        if self.path == "/api/chat":
            content_length = int(self.headers.get("Content-Length", 0))
            post_data = self.rfile.read(content_length)
            try:
                payload = json.loads(post_data.decode("utf-8"))
            except Exception:
                payload = {}

            user_query = payload.get("message", "").strip()
            case_id = payload.get("case_id") or get_active_case_id()

            if not user_query:
                result = {"reply": "Please state your question.", "status": "empty_query"}
            else:
                result = generate_voice_assistant_response(user_query, case_id)

            body = json.dumps(result).encode("utf-8")
            self.send_response(200)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self._send_cors_headers()
            self.end_headers()

    def log_message(self, format, *args):
        return


def start_voice_chat_server(port: int = 8502) -> bool:
    global _SERVER_INSTANCE
    with _SERVER_LOCK:
        if _SERVER_INSTANCE is not None:
            return True
        try:
            server = ThreadingHTTPServer(("0.0.0.0", port), VoiceChatRequestHandler)
            server.daemon_threads = True
            thread = threading.Thread(target=server.serve_forever, daemon=True, name="RealityCheckVoiceServer")
            thread.start()
            _SERVER_INSTANCE = server
            logger.info(f"Voice Chat API server started on port {port}")
            return True
        except Exception as exc:
            logger.warning(f"Could not start voice chat server on port {port}: {exc}")
            return False


if __name__ == "__main__":
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8502
    print(f"Starting Reality Check Voice API on port {port}...")
    server = ThreadingHTTPServer(("0.0.0.0", port), VoiceChatRequestHandler)
    server.daemon_threads = True
    print(f"Voice API listening on http://127.0.0.1:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
