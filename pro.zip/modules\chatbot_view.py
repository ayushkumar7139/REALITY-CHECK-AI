import streamlit as st
from google import genai
from google.genai import types
from modules.storage import get_all_cases, get_case_by_id
from modules.gemma_client import get_api_key, DEFAULT_GEMMA_MODEL
from modules.voice_chat_server import set_active_case_id


def render_chatbot_view():
    st.markdown("""
    <div style="margin-bottom: 1.25rem;">
        <h2 style="margin: 0; font-size: 1.4rem; font-weight: 700; color: #FFFFFF;">AI Investigator Copilot</h2>
        <p style="margin: 0.2rem 0 0 0; color: #94A3B8; font-size: 0.9rem;">
            Interactive visual troubleshooting, voice interaction, safety code queries, on-site guidance, and problem resolution powered by Gemma.
        </p>
    </div>
    """, unsafe_allow_html=True)

    cases = get_all_cases()
    if not cases:
        st.info("No cases currently recorded. Log an inspection first to chat with case context.")
        active_case = None
    else:
        case_ids = [c["id"] for c in cases]
        selected_id = st.session_state.get("selected_case_id", case_ids[0])
        if selected_id not in case_ids:
            selected_id = case_ids[0]
            
        col_c1, col_c2 = st.columns([8, 4])
        with col_c1:
            chosen = st.selectbox(
                "Active Investigation Context",
                [f"{c['id']} — {c.get('title', 'Untitled')[:45]}" for c in cases],
                index=case_ids.index(selected_id)
            )
            selected_id = chosen.split(" — ")[0]
            st.session_state["selected_case_id"] = selected_id
            set_active_case_id(selected_id)
            active_case = get_case_by_id(selected_id)
        with col_c2:
            st.markdown("<div style='padding-top:1.8rem;'>", unsafe_allow_html=True)
            if st.button("Clear Conversation", icon=":material/delete:", use_container_width=True):
                st.session_state["copilot_messages"] = []
                st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)

    # Initialize chat history
    if "copilot_messages" not in st.session_state:
        st.session_state["copilot_messages"] = [
            {
                "role": "assistant",
                "content": "Hello! I am your **Reality Check AI Copilot** powered by Gemma. I can help you troubleshoot on-site issues, interpret visual findings, draft escalation notices, or recommend safe remediation protocols. What would you like to explore?"
            }
        ]

    # Quick prompt pills
    st.markdown("<div style='font-size:0.78rem; font-weight:700; text-transform:uppercase; color:#94A3B8; letter-spacing:0.05em; margin:0.8rem 0 0.4rem 0;'>Quick Inquiries</div>", unsafe_allow_html=True)
    qp1, qp2, qp3, qp4 = st.columns(4)
    quick_query = None
    with qp1:
        if st.button("Containment Steps", icon=":material/warning:", use_container_width=True):
            quick_query = "What immediate temporary containment steps should be implemented on-site to mitigate this hazard right now?"
    with qp2:
        if st.button("Required Specialists", icon=":material/engineering:", use_container_width=True):
            quick_query = "What specific contractor trade or qualified specialists should be dispatched to address this issue?"
    with qp3:
        if st.button("Safety Regulations", icon=":material/policy:", use_container_width=True):
            quick_query = "Which life-safety, building, or ADA accessibility standards typically govern this type of defect?"
    with qp4:
        if st.button("Draft Urgent Ticket", icon=":material/mail:", use_container_width=True):
            quick_query = "Draft a formal, urgent escalation ticket message ready to send to building facilities management."

    # Build system context string from active case
    context_str = "No specific case selected."
    if active_case:
        f = active_case.get("ai_findings", {})
        checklist_items = [t.get("task", "") for t in f.get("verification_checklist", []) if isinstance(t, dict)]
        context_str = f"""
ACTIVE CASE ID: {active_case.get('id')}
TITLE: {active_case.get('title')}
LOCATION: {active_case.get('location')}
CATEGORY: {active_case.get('category')}
STATUS: {active_case.get('status')}
ASSESSED PRIORITY: {f.get('suggested_priority', 'Moderate')}
SUMMARY: {f.get('summary', 'None')}
VERIFIED VISUAL FACTS: {', '.join(f.get('visual_observations', []))}
HYPOTHESES: {', '.join(f.get('possible_interpretations', []))}
UNKNOWNS: {', '.join(f.get('unconfirmed_information', []))}
CHECKLIST: {', '.join(checklist_items[:6])}
"""

    # Display chat history
    for msg in st.session_state["copilot_messages"]:
        if msg["role"] == "user":
            with st.chat_message("user"):
                st.markdown(msg["content"])
        else:
            with st.chat_message("assistant"):
                st.markdown(msg["content"])

    # Handle input (either from chat box or quick query button)
    user_input = st.chat_input("Ask Gemma anything about this case, codes, or troubleshooting...")
    prompt_to_send = quick_query if quick_query else user_input

    if prompt_to_send:
        # Append user message
        st.session_state["copilot_messages"].append({"role": "user", "content": prompt_to_send})
        with st.chat_message("user"):
            st.markdown(prompt_to_send)

        # Call Gemma model
        with st.chat_message("assistant"):
            with st.spinner("Gemma is reasoning..."):
                try:
                    api_key = get_api_key()
                    client = genai.Client(api_key=api_key)
                    
                    full_prompt = f"""You are Reality Check AI Copilot, a senior diagnostic safety engineer and facilities investigator powered by Gemma.
You are assisting an on-site inspector with visual evidence troubleshooting.

CURRENT CASE RECORD IN CONTEXT:
{context_str}

CONVERSATION INQUIRY:
{prompt_to_send}

Provide a precise, authoritative, and practical safety analysis:"""

                    response = client.models.generate_content(
                        model=DEFAULT_GEMMA_MODEL,
                        contents=full_prompt,
                        config=types.GenerateContentConfig(
                            max_output_tokens=650,
                            temperature=0.2
                        )
                    )
                    
                    reply_text = ""
                    if hasattr(response, "text") and response.text:
                        reply_text = response.text.strip()
                    elif hasattr(response, "candidates") and response.candidates:
                        c = response.candidates[0]
                        if hasattr(c, "content") and hasattr(c.content, "parts") and c.content.parts:
                            reply_text = "".join(part.text or "" for part in c.content.parts).strip()
                            
                    if not reply_text:
                        reply_text = "I analyzed the case context but was unable to produce a recommendation. Please refine your query."
                        
                    st.markdown(reply_text)
                    st.session_state["copilot_messages"].append({"role": "assistant", "content": reply_text})
                except Exception as exc:
                    err_msg = f"Inference error: {str(exc)}"
                    st.error(err_msg)
                    st.session_state["copilot_messages"].append({"role": "assistant", "content": err_msg})
