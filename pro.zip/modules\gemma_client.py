import os
import json
import re
from typing import Dict, Any, Tuple
from PIL import Image, ImageOps
from google import genai
from google.genai import types

DEFAULT_GEMMA_MODEL = "gemma-4-26b-a4b-it"


def get_api_key() -> str:
    # 1. Try streamlit secrets if running inside streamlit
    try:
        import streamlit as st
        key = st.secrets.get("GOOGLE_API_KEY", "")
        if key and key.strip() and key.strip() != "YOUR_ACTUAL_API_KEY":
            return key.strip()
    except Exception:
        pass
    
    # 2. Try direct read from .streamlit/secrets.toml
    try:
        import tomllib
        from pathlib import Path
        secrets_path = Path(__file__).resolve().parent.parent / ".streamlit" / "secrets.toml"
        if secrets_path.exists():
            with open(secrets_path, "rb") as f:
                data = tomllib.load(f)
                key = data.get("GOOGLE_API_KEY", "")
                if key and key.strip() and key.strip() != "YOUR_ACTUAL_API_KEY":
                    return key.strip()
    except Exception:
        pass

    # 3. Try environment variable
    env_key = os.getenv("GOOGLE_API_KEY", "").strip()
    if env_key and env_key != "YOUR_ACTUAL_API_KEY":
        return env_key
    return ""


def test_gemma_connection(model_id: str = DEFAULT_GEMMA_MODEL, api_key: str = "") -> Tuple[bool, str]:
    key = api_key or get_api_key()
    if not key:
        return False, "API key is missing or set to placeholder value."
    try:
        client = genai.Client(api_key=key)
        resp = client.models.generate_content(
            model=model_id.strip(),
            contents="Respond with the word 'ONLINE' if you are active."
        )
        text = (resp.text or "").strip()
        return True, f"Connection successful! Model response: {text[:60]}"
    except Exception as exc:
        return False, f"Connection error: {str(exc)}"


def build_analysis_prompt(context: str, location: str, category: str, concern: str) -> str:
    return f"""You are Reality Check AI, an objective visual evidence investigator and diagnostic safety reasoning engine.
Analyze this image carefully.

CONTEXT FROM OPERATOR:
- Location: {location.strip() or "Not specified"}
- Context Notes: {context.strip() or "None"}
- Category: {category}
- Reported Concern: {concern}

CORE PRINCIPLES:
1. VISUAL EVIDENCE: Only document unmistakable visible facts in "visual_observations".
2. UNCERTAINTY: Clearly separate hypotheses ("possible_interpretations") and unknowns ("unconfirmed_information").
3. GENUINE ANNOTATIONS ONLY: If and only if a clear physical defect or focal point has an unmistakable center location in the image, provide its percentage coordinates (x: 0-100, y: 0-100) in "annotations". If none or uncertain, return an empty list []. NEVER fabricate bounding boxes or coordinates.
4. CONFIDENCE VS SEVERITY: "visual_confidence" is strictly image optical clarity. "suggested_priority" is operational hazard urgency.

Respond ONLY with valid JSON with this exact structure:
{{
  "summary": "1 to 2 concise sentences describing visible condition",
  "visual_observations": ["verified fact 1", "verified fact 2"],
  "possible_interpretations": ["plausible interpretation 1"],
  "unconfirmed_information": ["camera limitation or unknown 1"],
  "potential_consequences": ["realistic consequence 1"],
  "visual_confidence": "High" | "Medium" | "Low",
  "confidence_rationale": "brief reason regarding clarity and angle",
  "suggested_priority": "Immediate Attention" | "High" | "Moderate" | "Low",
  "priority_rationale": "brief operational reason",
  "verification_checklist": ["on-site verification task 1", "on-site verification task 2", "on-site verification task 3"],
  "recommended_actions": ["immediate safe action 1", "follow-up action 2"],
  "suggested_report_message": "polite 2-sentence dispatch message for maintenance",
  "limitations": "concise boundary statement regarding single photograph inference",
  "annotations": [
    {{"label": "defect name", "x": 50, "y": 45, "note": "brief note"}}
  ]
}}"""


def _clean_and_parse_json(raw_text: str) -> Dict[str, Any]:
    text = raw_text.strip()
    
    # Strip markdown code fencing if present
    if text.startswith("```"):
        pattern = r"```(?:json)?\s*([\s\S]*?)\s*```"
        match = re.search(pattern, text)
        if match:
            text = match.group(1).strip()
            
    # Direct JSON parse
    try:
        return json.loads(text)
    except Exception:
        pass
        
    # Search for first { and last }
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = text[start:end + 1]
        try:
            return json.loads(candidate)
        except Exception:
            pass

    return _fallback_markdown_parser(raw_text)


def _fallback_markdown_parser(text: str) -> Dict[str, Any]:
    result = {
        "summary": "Visual analysis conducted on submitted photograph.",
        "visual_observations": [],
        "possible_interpretations": [],
        "unconfirmed_information": [],
        "potential_consequences": [],
        "visual_confidence": "Medium",
        "confidence_rationale": "Single photographic perspective evaluated.",
        "suggested_priority": "Moderate",
        "priority_rationale": "Preliminary visual assessment pending physical site inspection.",
        "verification_checklist": ["Inspect site in person", "Confirm dimensions and substrate condition"],
        "recommended_actions": ["Restrict access if hazard exists", "Notify maintenance coordinator"],
        "suggested_report_message": "Inspection record submitted for review.",
        "limitations": "Guidance derived from automated visual model inference.",
        "annotations": []
    }
    
    lines = text.split("\n")
    current_key = None
    
    for line in lines:
        l = line.strip()
        lower = l.lower()
        if "summary" in lower and ("#" in l or ":" in l):
            current_key = "summary"
            continue
        elif "visible" in lower or "observation" in lower or "evidence" in lower:
            current_key = "visual_observations"
            continue
        elif "might mean" in lower or "interpretation" in lower:
            current_key = "possible_interpretations"
            continue
        elif "cannot confirm" in lower or "uncertain" in lower or "unknown" in lower:
            current_key = "unconfirmed_information"
            continue
        elif "consequence" in lower or "risk" in lower:
            current_key = "potential_consequences"
            continue
        elif "priority" in lower:
            if "immediate" in lower:
                result["suggested_priority"] = "Immediate Attention"
            elif "high" in lower:
                result["suggested_priority"] = "High"
            elif "low" in lower:
                result["suggested_priority"] = "Low"
            else:
                result["suggested_priority"] = "Moderate"
            continue
        elif "recommend" in lower or "action" in lower:
            current_key = "recommended_actions"
            continue
        elif "verify" in lower or "checklist" in lower:
            current_key = "verification_checklist"
            continue
            
        if l and current_key:
            clean_item = re.sub(r"^[-*0-9.]+\s*", "", l).strip()
            if clean_item:
                if isinstance(result[current_key], list):
                    result[current_key].append(clean_item)
                elif current_key == "summary" and len(result["summary"]) < 100:
                    result["summary"] = clean_item

    return result


def analyze_inspection_image(
    image: Image.Image,
    context: str,
    location: str,
    category: str,
    concern: str,
    model_id: str = DEFAULT_GEMMA_MODEL,
    api_key: str = ""
) -> Tuple[Dict[str, Any], str]:
    """
    Submits optimized image and prompt to Gemma multimodal model.
    Optimized for high-speed inference (resizes image to 512px max dimension, sets max_output_tokens=700).
    """
    key = api_key or get_api_key()
    if not key:
        raise ValueError("Google AI API Key not found. Please provide an API key in .streamlit/secrets.toml or Settings.")
        
    client = genai.Client(api_key=key)
    prompt = build_analysis_prompt(context, location, category, concern)
    
    # PERFORMANCE OPTIMIZATION:
    # Resize image to max 512x512 with LANCZOS to dramatically accelerate upload and vision token encoding
    optimized_img = ImageOps.exif_transpose(image).convert("RGB")
    if optimized_img.width > 512 or optimized_img.height > 512:
        optimized_img.thumbnail((512, 512), Image.Resampling.LANCZOS)
    
    # Configure generation parameters for speed & conciseness
    config = types.GenerateContentConfig(
        max_output_tokens=750,
        temperature=0.1
    )
    
    response = client.models.generate_content(
        model=model_id.strip(),
        contents=[prompt, optimized_img],
        config=config
    )
    
    # Extract text robustly
    raw_text = ""
    if hasattr(response, "text") and response.text:
        raw_text = response.text.strip()
    elif hasattr(response, "candidates") and response.candidates:
        c = response.candidates[0]
        if hasattr(c, "content") and hasattr(c.content, "parts") and c.content.parts:
            raw_text = "".join(part.text or "" for part in c.content.parts).strip()
            
    if not raw_text:
        raise ValueError("The Gemma model returned an empty response. Verify image format and model availability.")
        
    structured = _clean_and_parse_json(raw_text)
    
    # Format checklist into interactive objects with completed flags
    raw_checklist = structured.get("verification_checklist", [])
    formatted_checklist = []
    for idx, item in enumerate(raw_checklist, start=1):
        if isinstance(item, str):
            formatted_checklist.append({"id": idx, "task": item, "completed": False, "notes": ""})
        elif isinstance(item, dict):
            formatted_checklist.append(item)
    structured["verification_checklist"] = formatted_checklist
    
    # Ensure annotations is a list and validate coordinates
    annotations = structured.get("annotations", [])
    valid_annotations = []
    if isinstance(annotations, list):
        for ann in annotations:
            if isinstance(ann, dict) and "label" in ann:
                # clamp coordinates between 0 and 100
                x = max(0, min(100, float(ann.get("x", 50))))
                y = max(0, min(100, float(ann.get("y", 50))))
                valid_annotations.append({
                    "label": str(ann.get("label", "Finding")),
                    "x": x,
                    "y": y,
                    "note": str(ann.get("note", ""))
                })
    structured["annotations"] = valid_annotations
    
    return structured, raw_text
