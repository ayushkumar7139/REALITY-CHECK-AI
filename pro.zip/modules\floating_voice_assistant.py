"""
Floating AI Voice Assistant Component for Reality Check AI.
Embeds a floating trigger button and slide-up chat drawer directly into the main window.
Features:
- Fixed to bottom-right corner of screen (z-index 2147483647).
- Clean vector SVG microphone icon (no emoji).
- Functional Close (✕) and Minimize (—) controls with instant panel hide and audio cancellation.
- Speech recognition (voice input) via Web Speech API.
- Spoken AI responses (TTS) via Web Speech API with Stop Speaking and Mute controls.
- Direct connection to Google Gemma multimodal model via port 8502 /api/chat.
- Active inspection context injection.
"""

import json
from pathlib import Path
import streamlit.components.v1 as components
from modules.voice_chat_server import start_voice_chat_server, get_active_case_id, set_active_case_id
from modules.storage import get_case_by_id


def render_floating_assistant(active_case_id: str = None) -> None:
    # Ensure background voice API server is running on port 8502
    start_voice_chat_server(8502)

    case_id = active_case_id or get_active_case_id() or ""
    if case_id:
        set_active_case_id(case_id)

    case = get_case_by_id(case_id) if case_id else None
    case_title = case.get("title", "General Inspection") if case else "General Inspection"
    severity = case.get("ai_findings", {}).get("suggested_priority", "Normal") if case else "Normal"

    # Escape case title for safe JS string literal
    safe_title = json.dumps(case_title[:36])[1:-1]
    safe_case_id = json.dumps(case_id)[1:-1]

    component_html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
</head>
<body style="margin:0; padding:0; overflow:hidden;">
<script>
(function() {{
    try {{
        const pDoc = window.parent.document;
        const pWin = window.parent;

        // Clean up previous elements if any
        const existingStyles = pDoc.getElementById("rc-voice-styles");
        if (existingStyles) existingStyles.remove();

        const existingRoot = pDoc.getElementById("rc-voice-root");
        if (existingRoot) existingRoot.remove();

        // 1. Inject Styles into parent document
        const style = pDoc.createElement("style");
        style.id = "rc-voice-styles";
        style.textContent = `
            /* Fixed Floating Trigger Button */
            #rc-voice-trigger {{
                position: fixed !important;
                bottom: 24px !important;
                right: 28px !important;
                width: 62px !important;
                height: 62px !important;
                border-radius: 50% !important;
                border: 2px solid rgba(255, 255, 255, 0.25) !important;
                background: linear-gradient(135deg, #EC4899 0%, #8B5CF6 50%, #06B6D4 100%) !important;
                box-shadow: 0 10px 35px rgba(236, 72, 153, 0.6), 0 0 25px rgba(6, 182, 212, 0.45) !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                z-index: 2147483647 !important;
                transition: transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.25s ease !important;
                outline: none !important;
                padding: 0 !important;
            }}
            #rc-voice-trigger:hover {{
                transform: scale(1.1) !important;
                box-shadow: 0 14px 45px rgba(236, 72, 153, 0.75), 0 0 35px rgba(6, 182, 212, 0.6) !important;
            }}
            #rc-voice-trigger:active {{
                transform: scale(0.95) !important;
            }}
            .rc-trigger-pulse {{
                position: absolute !important;
                top: 2px !important;
                right: 2px !important;
                width: 14px !important;
                height: 14px !important;
                background: #10B981 !important;
                border-radius: 50% !important;
                border: 2px solid #07090E !important;
                animation: rc-pulse-glow 2s infinite !important;
            }}
            @keyframes rc-pulse-glow {{
                0% {{ box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.7); }}
                70% {{ box-shadow: 0 0 0 10px rgba(16, 185, 129, 0); }}
                100% {{ box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }}
            }}

            /* Floating Chat Panel */
            #rc-voice-panel {{
                position: fixed !important;
                bottom: 98px !important;
                right: 28px !important;
                width: 440px !important;
                max-width: calc(100vw - 36px) !important;
                height: 600px !important;
                max-height: calc(100vh - 120px) !important;
                background: rgba(10, 14, 23, 0.98) !important;
                backdrop-filter: blur(28px) !important;
                -webkit-backdrop-filter: blur(28px) !important;
                border: 1px solid rgba(236, 72, 153, 0.35) !important;
                border-radius: 22px !important;
                box-shadow: 0 25px 65px rgba(0, 0, 0, 0.85), 0 0 40px rgba(139, 92, 246, 0.3) !important;
                display: flex !important;
                flex-direction: column !important;
                overflow: hidden !important;
                z-index: 2147483647 !important;
                color: #FFFFFF !important;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
                transition: opacity 0.2s ease, transform 0.2s ease !important;
            }}

            /* Higher specificity rule to ensure hidden state overrides display:flex */
            #rc-voice-panel.rc-panel-hidden {{
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }}

            /* Header */
            .rc-v-header {{
                padding: 14px 18px 10px 18px !important;
                background: linear-gradient(180deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.3) 100%) !important;
                border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
            }}
            .rc-v-header-top {{
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
            }}
            .rc-v-brand {{
                display: flex !important;
                align-items: center !important;
                gap: 10px !important;
            }}
            .rc-v-brand-icon {{
                width: 34px !important;
                height: 34px !important;
                border-radius: 10px !important;
                background: linear-gradient(135deg, #EC4899 0%, #8B5CF6 100%) !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
            }}
            .rc-v-brand-name {{
                font-size: 0.95rem !important;
                font-weight: 700 !important;
                color: #FFFFFF !important;
                line-height: 1.2 !important;
            }}
            .rc-v-brand-sub {{
                font-size: 0.7rem !important;
                color: #06B6D4 !important;
                font-weight: 600 !important;
            }}
            .rc-v-actions {{
                display: flex !important;
                align-items: center !important;
                gap: 6px !important;
            }}
            .rc-v-action-btn {{
                background: rgba(255, 255, 255, 0.06) !important;
                border: 1px solid rgba(255, 255, 255, 0.1) !important;
                color: #94A3B8 !important;
                border-radius: 8px !important;
                padding: 6px 9px !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                gap: 5px !important;
                font-size: 0.72rem !important;
                transition: all 0.2s !important;
                outline: none !important;
            }}
            .rc-v-action-btn:hover {{
                background: rgba(255, 255, 255, 0.14) !important;
                color: #FFFFFF !important;
            }}
            .rc-v-send-btn svg, .rc-v-send-btn svg line, .rc-v-send-btn svg polygon,
            .rc-v-mic-btn svg, .rc-v-mic-btn svg path, .rc-v-mic-btn svg line,
            .rc-v-action-btn svg, .rc-v-action-btn svg line, .rc-v-action-btn svg path, .rc-v-action-btn svg polygon, .rc-v-action-btn svg rect {{
                pointer-events: none !important;
            }}
            #rc-v-btn-stop-tts {{
                background: rgba(236, 72, 153, 0.18) !important;
                border-color: rgba(236, 72, 153, 0.45) !important;
                color: #F472B6 !important;
                font-weight: 600 !important;
            }}
            #rc-v-btn-minimize:hover {{
                background: rgba(255, 255, 255, 0.15) !important;
                color: #FFFFFF !important;
            }}
            #rc-v-btn-close:hover {{
                background: rgba(239, 68, 68, 0.22) !important;
                border-color: rgba(239, 68, 68, 0.5) !important;
                color: #EF4444 !important;
            }}
            #rc-v-btn-close:hover svg {{
                stroke: #EF4444 !important;
            }}

            /* Ribbon */
            .rc-v-ribbon {{
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
                margin-top: 10px !important;
                padding-top: 8px !important;
                border-top: 1px solid rgba(255, 255, 255, 0.06) !important;
                font-size: 0.75rem !important;
            }}
            .rc-v-case-badge {{
                display: flex !important;
                align-items: center !important;
                gap: 6px !important;
                background: rgba(15, 23, 42, 0.8) !important;
                border: 1px solid rgba(139, 92, 246, 0.3) !important;
                padding: 3px 8px !important;
                border-radius: 6px !important;
                max-width: 260px !important;
                white-space: nowrap !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
            }}
            .rc-v-case-id {{
                color: #A855F7 !important;
                font-weight: 700 !important;
                font-family: monospace !important;
            }}
            .rc-v-case-title {{
                color: #E2E8F0 !important;
                overflow: hidden !important;
                text-overflow: ellipsis !important;
            }}
            .rc-v-status {{
                display: flex !important;
                align-items: center !important;
                gap: 5px !important;
            }}
            .rc-v-status-dot {{
                width: 8px !important;
                height: 8px !important;
                border-radius: 50% !important;
                background: #10B981 !important;
            }}
            .rc-v-status-text {{
                font-size: 0.72rem !important;
                color: #94A3B8 !important;
                font-weight: 600 !important;
            }}

            /* Notice */
            .rc-v-notice {{
                background: rgba(245, 158, 11, 0.12) !important;
                border-bottom: 1px solid rgba(245, 158, 11, 0.25) !important;
                color: #FDE68A !important;
                font-size: 0.72rem !important;
                padding: 7px 14px !important;
                display: flex !important;
                align-items: center !important;
                gap: 8px !important;
            }}
            .rc-v-privacy {{
                background: rgba(255, 255, 255, 0.02) !important;
                color: #64748B !important;
                font-size: 0.68rem !important;
                padding: 4px 16px !important;
                text-align: center !important;
                border-bottom: 1px solid rgba(255, 255, 255, 0.04) !important;
            }}

            /* Chips */
            .rc-v-chips {{
                display: flex !important;
                gap: 6px !important;
                padding: 8px 14px !important;
                overflow-x: auto !important;
                white-space: nowrap !important;
                border-bottom: 1px solid rgba(255, 255, 255, 0.05) !important;
            }}
            .rc-v-chip {{
                background: rgba(30, 41, 59, 0.6) !important;
                border: 1px solid rgba(255, 255, 255, 0.08) !important;
                color: #CBD5E1 !important;
                font-size: 0.72rem !important;
                font-weight: 500 !important;
                padding: 4px 10px !important;
                border-radius: 12px !important;
                cursor: pointer !important;
                transition: all 0.18s !important;
                flex-shrink: 0 !important;
            }}
            .rc-v-chip:hover {{
                background: rgba(236, 72, 153, 0.18) !important;
                border-color: rgba(236, 72, 153, 0.45) !important;
                color: #FFFFFF !important;
            }}

            /* Messages Body */
            .rc-v-body {{
                flex: 1 !important;
                padding: 14px !important;
                overflow-y: auto !important;
                display: flex !important;
                flex-direction: column !important;
                gap: 12px !important;
            }}
            .rc-v-msg {{
                display: flex !important;
                gap: 10px !important;
                max-width: 90% !important;
            }}
            .rc-v-msg-user {{
                align-self: flex-end !important;
                flex-direction: row-reverse !important;
            }}
            .rc-v-msg-assistant {{
                align-self: flex-start !important;
            }}
            .rc-v-msg-avatar {{
                width: 26px !important;
                height: 26px !important;
                border-radius: 50% !important;
                background: rgba(255, 255, 255, 0.08) !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                flex-shrink: 0 !important;
            }}
            .rc-v-msg-user .rc-v-msg-avatar {{
                background: linear-gradient(135deg, #8B5CF6 0%, #06B6D4 100%) !important;
            }}
            .rc-v-msg-bubble {{
                padding: 10px 14px !important;
                border-radius: 14px !important;
                font-size: 0.85rem !important;
                line-height: 1.45 !important;
            }}
            .rc-v-msg-user .rc-v-msg-bubble {{
                background: linear-gradient(135deg, rgba(139, 92, 246, 0.3) 0%, rgba(6, 182, 212, 0.25) 100%) !important;
                border: 1px solid rgba(139, 92, 246, 0.4) !important;
                color: #FFFFFF !important;
                border-bottom-right-radius: 3px !important;
            }}
            .rc-v-msg-assistant .rc-v-msg-bubble {{
                background: rgba(18, 24, 38, 0.85) !important;
                border: 1px solid rgba(236, 72, 153, 0.25) !important;
                color: #F8FAFC !important;
                border-bottom-left-radius: 3px !important;
            }}
            .rc-v-msg-footer {{
                display: flex !important;
                align-items: center !important;
                justify-content: space-between !important;
                margin-top: 5px !important;
                font-size: 0.68rem !important;
                color: #64748B !important;
            }}
            .rc-v-btn-replay {{
                background: none !important;
                border: none !important;
                color: #94A3B8 !important;
                cursor: pointer !important;
                padding: 2px 4px !important;
                display: flex !important;
                align-items: center !important;
                gap: 4px !important;
                font-size: 0.68rem !important;
            }}
            .rc-v-btn-replay:hover {{
                color: #06B6D4 !important;
            }}

            /* Waveform Overlay */
            .rc-v-waveform {{
                background: rgba(15, 23, 42, 0.95) !important;
                border-top: 1px solid rgba(236, 72, 153, 0.3) !important;
                padding: 12px !important;
                display: flex !important;
                flex-direction: column !important;
                align-items: center !important;
                gap: 8px !important;
            }}
            .rc-v-bars {{
                display: flex !important;
                align-items: center !important;
                gap: 5px !important;
                height: 24px !important;
            }}
            .rc-v-bar {{
                width: 4px !important;
                background: linear-gradient(180deg, #EC4899 0%, #06B6D4 100%) !important;
                border-radius: 2px !important;
                animation: rc-wave-anim 1s ease-in-out infinite !important;
            }}
            .rc-vb-1 {{ height: 8px !important; animation-delay: 0.1s !important; }}
            .rc-vb-2 {{ height: 18px !important; animation-delay: 0.3s !important; }}
            .rc-vb-3 {{ height: 24px !important; animation-delay: 0.2s !important; }}
            .rc-vb-4 {{ height: 14px !important; animation-delay: 0.4s !important; }}
            .rc-vb-5 {{ height: 9px !important; animation-delay: 0.15s !important; }}
            @keyframes rc-wave-anim {{
                0%, 100% {{ transform: scaleY(0.4); }}
                50% {{ transform: scaleY(1.2); }}
            }}
            .rc-v-listening-label {{
                font-size: 0.78rem !important;
                color: #F472B6 !important;
                font-weight: 500 !important;
            }}

            /* Footer & Input Bar */
            .rc-v-footer {{
                padding: 12px 14px 14px 14px !important;
                background: rgba(10, 14, 23, 0.98) !important;
                border-top: 1px solid rgba(255, 255, 255, 0.08) !important;
            }}
            .rc-v-input-bar {{
                display: flex !important;
                align-items: center !important;
                gap: 8px !important;
                background: rgba(18, 24, 38, 0.9) !important;
                border: 1px solid rgba(255, 255, 255, 0.12) !important;
                border-radius: 24px !important;
                padding: 4px 6px 4px 12px !important;
            }}
            .rc-v-input-bar:focus-within {{
                border-color: #8B5CF6 !important;
                box-shadow: 0 0 16px rgba(139, 92, 246, 0.3) !important;
            }}
            .rc-v-mic-btn {{
                background: none !important;
                border: none !important;
                color: #94A3B8 !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                width: 32px !important;
                height: 32px !important;
                border-radius: 50% !important;
                padding: 0 !important;
                transition: all 0.2s !important;
            }}
            .rc-v-mic-btn:hover {{
                color: #06B6D4 !important;
                background: rgba(6, 182, 212, 0.1) !important;
            }}
            .rc-v-mic-active {{
                color: #FFFFFF !important;
                background: linear-gradient(135deg, #EC4899 0%, #EF4444 100%) !important;
                box-shadow: 0 0 12px rgba(236, 72, 153, 0.6) !important;
                animation: rc-mic-pulse 1.2s infinite !important;
            }}
            @keyframes rc-mic-pulse {{
                0% {{ box-shadow: 0 0 0 0 rgba(236, 72, 153, 0.7); }}
                70% {{ box-shadow: 0 0 0 10px rgba(236, 72, 153, 0); }}
                100% {{ box-shadow: 0 0 0 0 rgba(236, 72, 153, 0); }}
            }}
            #rc-v-input {{
                flex: 1 !important;
                background: transparent !important;
                border: none !important;
                color: #FFFFFF !important;
                font-size: 0.85rem !important;
                outline: none !important;
                padding: 6px 4px !important;
            }}
            #rc-v-input::placeholder {{
                color: #64748B !important;
            }}
            .rc-v-send-btn {{
                width: 32px !important;
                height: 32px !important;
                border-radius: 50% !important;
                background: linear-gradient(135deg, #EC4899 0%, #8B5CF6 100%) !important;
                border: none !important;
                cursor: pointer !important;
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                padding: 0 !important;
                transition: transform 0.18s !important;
            }}
            .rc-v-send-btn:hover {{
                transform: scale(1.06) !important;
            }}
            .rc-v-send-btn:active {{
                transform: scale(0.95) !important;
            }}
            .rc-v-hidden {{
                display: none !important;
            }}

            @media (max-width: 480px) {{
                #rc-voice-trigger {{
                    bottom: 16px !important;
                    right: 16px !important;
                }}
                #rc-voice-panel {{
                    right: 12px !important;
                    left: 12px !important;
                    bottom: 84px !important;
                    width: calc(100vw - 24px) !important;
                    height: 72vh !important;
                }}
            }}
        `;
        pDoc.head.appendChild(style);

        // 2. Inject Elements into parent document body
        const root = pDoc.createElement("div");
        root.id = "rc-voice-root";
        root.innerHTML = `
            <!-- Floating Trigger Button -->
            <button id="rc-voice-trigger" aria-label="Open Reality Check AI Voice Assistant" title="Open Reality Check AI Voice Assistant">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                    <line x1="12" x2="12" y1="19" y2="22"/>
                </svg>
                <span class="rc-trigger-pulse"></span>
            </button>

            <!-- Floating Chat Panel -->
            <div id="rc-voice-panel" class="rc-panel-hidden" role="dialog" aria-labelledby="rc-v-title">
                <div class="rc-v-header">
                    <div class="rc-v-header-top">
                        <div class="rc-v-brand">
                            <div class="rc-v-brand-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                                    <line x1="12" x2="12" y1="19" y2="22"/>
                                </svg>
                            </div>
                            <div>
                                <div id="rc-v-title" class="rc-v-brand-name">AI Voice Assistant</div>
                                <div class="rc-v-brand-sub">Gemma 4 Multimodal</div>
                            </div>
                        </div>

                        <div class="rc-v-actions">
                            <button id="rc-v-btn-stop-tts" class="rc-v-action-btn rc-v-hidden" title="Stop Spoken Voice" aria-label="Stop Speaking">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="#EC4899">
                                    <rect x="4" y="4" width="16" height="16" rx="2"></rect>
                                </svg>
                                <span>Stop Voice</span>
                            </button>

                            <button id="rc-v-btn-toggle-sound" class="rc-v-action-btn" title="Toggle Spoken Responses" aria-label="Toggle Voice Output">
                                <svg id="rc-v-vol-on" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                                    <path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path>
                                    <path d="M19.07 4.93a10 10 0 0 1 0 14.14"></path>
                                </svg>
                                <svg id="rc-v-vol-off" class="rc-v-hidden" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon>
                                    <line x1="23" y1="9" x2="17" y2="15"></line>
                                    <line x1="17" y1="9" x2="23" y2="15"></line>
                                </svg>
                            </button>

                            <!-- Minimize Control -->
                            <button id="rc-v-btn-minimize" class="rc-v-action-btn" title="Minimize Panel" aria-label="Minimize Assistant">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                </svg>
                            </button>

                            <!-- Close (Cross) Control -->
                            <button id="rc-v-btn-close" class="rc-v-action-btn" title="Close Panel" aria-label="Close Assistant">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="18" y1="6" x2="6" y2="18"></line>
                                    <line x1="6" y1="6" x2="18" y2="18"></line>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div class="rc-v-ribbon">
                        <div class="rc-v-case-badge" title="Active Case">
                            <span class="rc-v-case-id">{safe_case_id or "General"}</span>
                            <span class="rc-v-case-title">{safe_title}</span>
                        </div>
                        <div class="rc-v-status">
                            <span class="rc-v-status-dot" id="rc-v-dot"></span>
                            <span class="rc-v-status-text" id="rc-v-status-txt">Ready</span>
                        </div>
                    </div>
                </div>

                <div id="rc-v-browser-notice" class="rc-v-notice rc-v-hidden">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="8" x2="12" y2="12"></line>
                        <line x1="12" y1="16" x2="12.01" y2="16"></line>
                    </svg>
                    <span id="rc-v-notice-text">Speech recognition is not supported in this browser. You can type questions below.</span>
                </div>

                <div class="rc-v-privacy">
                    <span>Voice processed locally via Web Speech API. Audio is never stored.</span>
                </div>

                <div class="rc-v-chips">
                    <button class="rc-v-chip" data-q="What immediate life-safety hazards or physical risks were detected in this inspection?">Immediate Hazards</button>
                    <button class="rc-v-chip" data-q="Generate a step-by-step physical verification checklist for this case.">Investigation Checklist</button>
                    <button class="rc-v-chip" data-q="What root causes and environmental factors should I investigate on site?">Root Cause Analysis</button>
                    <button class="rc-v-chip" data-q="Draft an urgent facilities maintenance dispatch ticket for this finding.">Dispatch Ticket</button>
                </div>

                <div class="rc-v-body" id="rc-v-messages"></div>

                <div id="rc-v-listening" class="rc-v-waveform rc-v-hidden">
                    <div class="rc-v-bars">
                        <span class="rc-v-bar rc-vb-1"></span>
                        <span class="rc-v-bar rc-vb-2"></span>
                        <span class="rc-v-bar rc-vb-3"></span>
                        <span class="rc-v-bar rc-vb-4"></span>
                        <span class="rc-v-bar rc-vb-5"></span>
                    </div>
                    <div class="rc-v-listening-label" id="rc-v-transcript">Listening... Speak now into your microphone.</div>
                </div>

                <div class="rc-v-footer">
                    <div class="rc-v-input-bar">
                        <button id="rc-v-mic" class="rc-v-mic-btn" title="Click to speak (Voice Input)" aria-label="Start Voice Input">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/>
                                <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
                                <line x1="12" x2="12" y1="19" y2="22"/>
                            </svg>
                        </button>

                        <input type="text" id="rc-v-input" placeholder="Ask about risks, checklists, or tap mic..." autocomplete="off" />

                        <button id="rc-v-send" class="rc-v-send-btn" title="Send Question" aria-label="Send Message">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="22" y1="2" x2="11" y2="13"></line>
                                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        `;
        pDoc.body.appendChild(root);

        // 3. Attach JavaScript Controller
        pWin._rcChat = pWin._rcChat || {{
            isOpen: false,
            soundEnabled: true,
            messages: [
                {{
                    role: "assistant",
                    text: "Hello! I am your <strong>Reality Check Voice Assistant</strong> powered by Gemma. You can speak to me by tapping the microphone button or type below. Ask me about detected hazards, investigation tasks, or safety codes."
                }}
            ]
        }};

        const triggerBtn = pDoc.getElementById("rc-voice-trigger");
        const panel = pDoc.getElementById("rc-voice-panel");
        const closeBtn = pDoc.getElementById("rc-v-btn-close");
        const minBtn = pDoc.getElementById("rc-v-btn-minimize");
        const micBtn = pDoc.getElementById("rc-v-mic");
        const sendBtn = pDoc.getElementById("rc-v-send");
        const textInput = pDoc.getElementById("rc-v-input");
        const messagesContainer = pDoc.getElementById("rc-v-messages");
        const listeningOverlay = pDoc.getElementById("rc-v-listening");
        const liveTranscript = pDoc.getElementById("rc-v-transcript");
        const stopTtsBtn = pDoc.getElementById("rc-v-btn-stop-tts");
        const toggleSoundBtn = pDoc.getElementById("rc-v-btn-toggle-sound");
        const volOn = pDoc.getElementById("rc-v-vol-on");
        const volOff = pDoc.getElementById("rc-v-vol-off");
        const dot = pDoc.getElementById("rc-v-dot");
        const statusTxt = pDoc.getElementById("rc-v-status-txt");
        const notice = pDoc.getElementById("rc-v-browser-notice");
        const noticeTxt = pDoc.getElementById("rc-v-notice-text");

        // State Machine & Close / Open Controllers
        function closeAssistant() {{
            pWin._rcChat.isOpen = false;
            if (panel) {{
                panel.classList.add("rc-panel-hidden");
                panel.style.setProperty("display", "none", "important");
                panel.style.setProperty("visibility", "hidden", "important");
            }}

            // Stop speech synthesis if speaking
            if ("speechSynthesis" in pWin) {{
                try {{ pWin.speechSynthesis.cancel(); }} catch(e) {{}}
            }}
            if (stopTtsBtn) stopTtsBtn.classList.add("rc-v-hidden");

            // Stop speech recognition if listening
            if (isListening && recognition) {{
                try {{ recognition.stop(); }} catch(e) {{}}
            }}
            isListening = false;
            if (micBtn) micBtn.classList.remove("rc-v-mic-active");
            if (listeningOverlay) listeningOverlay.classList.add("rc-v-hidden");

            setStatus("ready", "Ready");
        }}

        function openAssistant() {{
            pWin._rcChat.isOpen = true;
            if (panel) {{
                panel.classList.remove("rc-panel-hidden");
                panel.style.setProperty("display", "flex", "important");
                panel.style.setProperty("visibility", "visible", "important");
            }}
            if (textInput) textInput.focus();
        }}

        // Expose controllers to window so any trigger can invoke them reliably
        pWin._rcCloseChat = closeAssistant;
        pWin._rcOpenChat = openAssistant;
        pWin._rcToggleChat = function() {{
            if (pWin._rcChat.isOpen) {{
                closeAssistant();
            }} else {{
                openAssistant();
            }}
        }};

        // Restore open/closed state on render
        if (pWin._rcChat.isOpen) {{
            openAssistant();
        }} else {{
            closeAssistant();
        }}

        // Restore sound toggle state
        if (!pWin._rcChat.soundEnabled) {{
            if (volOn) volOn.classList.add("rc-v-hidden");
            if (volOff) volOff.classList.remove("rc-v-hidden");
        }}

        function setStatus(state, msg) {{
            if (!statusTxt || !dot) return;
            statusTxt.textContent = msg;
            if (state === "ready") dot.style.background = "#10B981";
            else if (state === "listening") dot.style.background = "#EC4899";
            else if (state === "processing") dot.style.background = "#8B5CF6";
            else if (state === "speaking") dot.style.background = "#06B6D4";
            else if (state === "error") dot.style.background = "#EF4444";
        }}

        const SpeechRecognition = pWin.SpeechRecognition || pWin.webkitSpeechRecognition;
        const hasRec = !!SpeechRecognition;
        const hasTts = "speechSynthesis" in pWin;

        if (!hasRec) {{
            if (notice) notice.classList.remove("rc-v-hidden");
            if (noticeTxt) noticeTxt.textContent = "Speech recognition is not supported in this browser. You can type questions directly in the box below.";
            if (micBtn) {{
                micBtn.style.opacity = "0.4";
                micBtn.title = "Voice recognition not supported in this browser - please type below";
            }}
        }}

        let isListening = false;
        let recognition = null;

        if (hasRec) {{
            try {{
                recognition = new SpeechRecognition();
                recognition.continuous = false;
                recognition.interimResults = true;
                recognition.lang = "en-US";

                recognition.onstart = function() {{
                    isListening = true;
                    if (micBtn) micBtn.classList.add("rc-v-mic-active");
                    if (listeningOverlay) listeningOverlay.classList.remove("rc-v-hidden");
                    if (liveTranscript) liveTranscript.textContent = "Listening... Speak now into your microphone.";
                    setStatus("listening", "Listening...");
                }};

                recognition.onresult = function(event) {{
                    let interim = "";
                    let finalT = "";
                    for (let i = event.resultIndex; i < event.results.length; ++i) {{
                        if (event.results[i].isFinal) finalT += event.results[i][0].transcript;
                        else interim += event.results[i][0].transcript;
                    }}
                    const txt = finalT || interim;
                    if (txt) {{
                        if (liveTranscript) liveTranscript.textContent = '“' + txt + '”';
                        if (textInput) textInput.value = txt;
                    }}
                }};

                recognition.onerror = function(event) {{
                    isListening = false;
                    if (micBtn) micBtn.classList.remove("rc-v-mic-active");
                    if (listeningOverlay) listeningOverlay.classList.add("rc-v-hidden");
                    if (event.error === "not-allowed" || event.error === "permission-denied") {{
                        if (notice) notice.classList.remove("rc-v-hidden");
                        if (noticeTxt) noticeTxt.textContent = "Microphone access was denied. Please allow microphone permissions in your browser or type below.";
                        setStatus("error", "Mic Denied");
                    }} else {{
                        setStatus("error", "Voice error");
                    }}
                    setTimeout(() => setStatus("ready", "Ready"), 3500);
                }};

                recognition.onend = function() {{
                    isListening = false;
                    if (micBtn) micBtn.classList.remove("rc-v-mic-active");
                    if (listeningOverlay) listeningOverlay.classList.add("rc-v-hidden");
                    setStatus("ready", "Ready");
                    if (textInput && textInput.value.trim().length > 2) {{
                        sendUserMessage(textInput.value.trim());
                    }}
                }};
            }} catch(e) {{
                console.error("SpeechRecognition error:", e);
            }}
        }}

        function toggleMic() {{
            if (!hasRec) {{
                if (notice) notice.classList.remove("rc-v-hidden");
                if (noticeTxt) noticeTxt.textContent = "Voice input is not supported in this browser. Please type your message below.";
                if (textInput) textInput.focus();
                return;
            }}
            stopSpeaking();
            if (isListening) {{
                try {{ recognition.stop(); }} catch(e) {{}}
            }} else {{
                try {{ recognition.start(); }} catch(e) {{ console.error(e); }}
            }}
        }}

        function speakText(txt) {{
            if (!hasTts || !pWin._rcChat.soundEnabled) return;
            pWin.speechSynthesis.cancel();

            const cleaned = txt
                .replace(/[*#`_~>-]/g, " ")
                .replace(/\\[([^\\]]+)\\]\\([^\\)]+\\)/g, "$1")
                .replace(/\\s+/g, " ")
                .trim();
            if (!cleaned) return;

            const u = new pWin.SpeechSynthesisUtterance(cleaned);
            u.rate = 1.05;
            u.pitch = 1.0;
            u.lang = "en-US";

            u.onstart = function() {{
                if (stopTtsBtn) stopTtsBtn.classList.remove("rc-v-hidden");
                setStatus("speaking", "Speaking...");
            }};
            u.onend = function() {{
                if (stopTtsBtn) stopTtsBtn.classList.add("rc-v-hidden");
                setStatus("ready", "Ready");
            }};
            u.onerror = function() {{
                if (stopTtsBtn) stopTtsBtn.classList.add("rc-v-hidden");
                setStatus("ready", "Ready");
            }};

            pWin.speechSynthesis.speak(u);
        }}

        function stopSpeaking() {{
            if (hasTts) pWin.speechSynthesis.cancel();
            if (stopTtsBtn) stopTtsBtn.classList.add("rc-v-hidden");
            setStatus("ready", "Ready");
        }}

        function renderMessages() {{
            if (!messagesContainer) return;
            messagesContainer.innerHTML = "";
            pWin._rcChat.messages.forEach(msg => {{
                const d = pDoc.createElement("div");
                d.className = "rc-v-msg " + (msg.role === "user" ? "rc-v-msg-user" : "rc-v-msg-assistant");

                const av = pDoc.createElement("div");
                av.className = "rc-v-msg-avatar";
                av.innerHTML = msg.role === "user"
                    ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>'
                    : '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#EC4899" stroke-width="2"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/></svg>';

                const b = pDoc.createElement("div");
                b.className = "rc-v-msg-bubble";

                const tx = pDoc.createElement("div");
                tx.innerHTML = msg.text
                    .replace(/\\*\\*(.*?)\\*\\*/g, "<strong>$1</strong>")
                    .replace(/\\n\\s*-\\s*(.*?)/g, "<br>• $1")
                    .replace(/\\n\\s*(\\d+\\.)\\s*(.*?)/g, "<br><strong>$1</strong> $2")
                    .replace(/\\n/g, "<br>");

                const f = pDoc.createElement("div");
                f.className = "rc-v-msg-footer";
                f.innerHTML = '<span>' + (msg.role === "user" ? "You" : "Gemma AI") + '</span>';

                if (msg.role === "assistant") {{
                    const r = pDoc.createElement("button");
                    r.className = "rc-v-btn-replay";
                    r.innerHTML = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg> Listen';
                    r.onclick = function() {{ speakText(msg.text); }};
                    f.appendChild(r);
                }}

                b.appendChild(tx);
                b.appendChild(f);
                d.appendChild(av);
                d.appendChild(b);
                messagesContainer.appendChild(d);
            }});
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }}

        renderMessages();

        async function sendUserMessage(q) {{
            const query = q || (textInput ? textInput.value.trim() : "");
            if (!query) return;

            if (textInput) textInput.value = "";
            pWin._rcChat.messages.push({{ role: "user", text: query }});
            renderMessages();
            setStatus("processing", "Reasoning...");

            const tId = "rc-v-th-" + Date.now();
            const th = pDoc.createElement("div");
            th.id = tId;
            th.className = "rc-v-msg rc-v-msg-assistant";
            th.innerHTML = `
                <div class="rc-v-msg-avatar">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 14 14"></polyline></svg>
                </div>
                <div class="rc-v-msg-bubble" style="background:rgba(30,41,59,0.5);">
                    <span style="color:#A855F7; font-size:0.8rem;">Gemma reasoning with inspection context...</span>
                </div>
            `;
            if (messagesContainer) {{
                messagesContainer.appendChild(th);
                messagesContainer.scrollTop = messagesContainer.scrollHeight;
            }}

            try {{
                const host = window.location.hostname || (pWin ? pWin.location.hostname : "127.0.0.1");
                const apiUrl = "http://" + host + ":8502/api/chat";
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 20000);

                const res = await fetch(apiUrl, {{
                    method: "POST",
                    headers: {{ "Content-Type": "application/json" }},
                    body: JSON.stringify({{
                        message: query,
                        case_id: "{safe_case_id}"
                    }}),
                    signal: controller.signal
                }});
                clearTimeout(timeoutId);

                const e = pDoc.getElementById(tId);
                if (e) e.remove();

                if (!res.ok) throw new Error("HTTP " + res.status);
                const data = await res.json();
                const rep = data.reply || "I encountered an issue processing your query.";
                pWin._rcChat.messages.push({{ role: "assistant", text: rep }});
                renderMessages();
                speakText(rep);
            }} catch(err) {{
                const e = pDoc.getElementById(tId);
                if (e) e.remove();
                console.error("AI service error:", err);
                const errTxt = "Connection failure: Unable to reach AI service on port 8502. Ensure the Reality Check background server is running.";
                pWin._rcChat.messages.push({{ role: "assistant", text: errTxt }});
                renderMessages();
                setStatus("error", "Error");
                setTimeout(() => setStatus("ready", "Ready"), 4000);
            }}
        }}

        // Direct, robust event bindings with stopPropagation
        if (closeBtn) {{
            closeBtn.onclick = function(e) {{
                if (e) e.stopPropagation();
                closeAssistant();
            }};
            closeBtn.addEventListener("click", function(e) {{
                if (e) e.stopPropagation();
                closeAssistant();
            }});
        }}

        if (minBtn) {{
            minBtn.onclick = function(e) {{
                if (e) e.stopPropagation();
                closeAssistant();
            }};
            minBtn.addEventListener("click", function(e) {{
                if (e) e.stopPropagation();
                closeAssistant();
            }});
        }}

        if (triggerBtn) {{
            triggerBtn.onclick = function(e) {{
                if (e) e.stopPropagation();
                pWin._rcToggleChat();
            }};
        }}

        if (micBtn) {{ micBtn.onclick = function(e) {{ if (e) e.stopPropagation(); toggleMic(); }}; }}
        if (sendBtn) {{ sendBtn.onclick = function(e) {{ if (e) e.stopPropagation(); sendUserMessage(); }}; }}
        if (textInput) {{
            textInput.onkeydown = function(e) {{
                if (e.key === "Enter") {{
                    e.preventDefault();
                    sendUserMessage();
                }}
            }};
        }}

        if (stopTtsBtn) {{ stopTtsBtn.onclick = function(e) {{ if (e) e.stopPropagation(); stopSpeaking(); }}; }}

        if (toggleSoundBtn) {{
            toggleSoundBtn.onclick = function(e) {{
                if (e) e.stopPropagation();
                pWin._rcChat.soundEnabled = !pWin._rcChat.soundEnabled;
                if (!pWin._rcChat.soundEnabled) {{
                    stopSpeaking();
                    if (volOn) volOn.classList.add("rc-v-hidden");
                    if (volOff) volOff.classList.remove("rc-v-hidden");
                }} else {{
                    if (volOn) volOn.classList.remove("rc-v-hidden");
                    if (volOff) volOff.classList.add("rc-v-hidden");
                }}
            }};
        }}

        pDoc.querySelectorAll(".rc-v-chip").forEach(c => {{
            c.onclick = function(e) {{
                if (e) e.stopPropagation();
                const q = c.getAttribute("data-q");
                if (q) sendUserMessage(q);
            }};
        }});

    }} catch(e) {{
        console.error("Voice assistant mounting error:", e);
    }}
}})();
</script>
</body>
</html>"""

    # Use components.html with height 0 so it executes in iframe and injects into parent window
    components.html(component_html, height=0, width=0)
